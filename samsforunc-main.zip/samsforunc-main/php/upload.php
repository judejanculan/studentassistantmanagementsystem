<?php

include 'conn.php';

session_start();

/*
if(isset($_POST['submit'])){


    $pic_file = $_FILES['pic'];
    $itr_file = $_FILES['itr'];
    $brgy_clearance_file = $_FILES['brgy_clearance'];
    $form138_file = $_FILES['form138'];
    $bills_file = $_FILES['bills'];

    $pic_name = $pic_file['name'];
    $pic_tmp = $pic_file['tmp_name'];
    $pic_size = $pic_file['size'];
    $pic_error = $pic_file['error'];

    $itr_name = $itr_file['name'];
    $itr_tmp = $itr_file['tmp_name'];
    $itr_size  = $itr_file['size'];
    $itr_error = $itr_file['error'];

    $brgy_clearance_name = $brgy_clearance_file['name'];
    $brgy_clearance_tmp = $brgy_clearance_file['tmp_name'];
    $brgy_clearance_size = $brgy_clearance_file['size'];
    $brgy_clearance_error = $brgy_clearance_file['error'];

    $form138_name = $form138_file['name'];
    $form138_tmp = $form138_file['tmp_name'];
    $form138_size = $form138_file['size'];
    $form138_error = $form138_file['error'];

    $bills_name  = $bills_file['name'];
    $bills_tmp = $bills_file['tmp_name'];
    $bills_size = $bills_file['size'];
    $bills_error = $bills_file['error'];

    $pic_ext = explode('.', $pic_name);
    $pic_ext = strtolower(end($pic_ext));

    $itr_ext = explode('.', $itr_name);
    $itr_ext = strtolower(end($itr_ext));

    $brgy_clearance_ext = explode('.', $brgy_clearance_name);
    $brgy_clearance_ext = strtolower(end($brgy_clearance_ext));

    $brgy_clearance_ext = explode('.', $brgy_clearance_name);
    $brgy_clearance_ext = strtolower(end($brgy_clearance_ext));

    $form138_ext = explode('.', $form138_name);
    $form138_ext = strtolower(end($form138_ext));

    $bills_ext = explode('.', $bills_name);
    $bills_ext = strtolower(end($bills_ext));


    $allowed = array('jpeg', 'jpg', 'png', 'pdf', 'docx');

    $lname = $_SESSION['lname'];
    $fname = $_SESSION['fname'];

  /*  $sql = "SELECT * 
            FROM applicants
            WHERE `lname` = '$lname'
            AND `fname` = '$fname';";

    $result = mysqli_query($con, $sql);  

    $name = $lname . $fname;
 
        //pic
     if(in_array($pic_ext, $allowed)){
        if($pic_error === 0){
            if($pic_size <= 2097152){
                $pic_name_new = $name. '.' . $pic_ext;//uniqid('', true) . '.' . $file_ext;
                $pic_destination = '../resources/uploads/' . $pic_name_new;

                if(move_uploaded_file($pic_tmp, $pic_destination)){
                    echo "File uploaded successfully.";
                }
            }
        }
    }
        //itr
    if(in_array($itr_ext, $allowed)){
        if($itr_error === 0){
            if($itr_size <= 2097152){
                $itr_name_new = $name. '.' . $itr_ext;//uniqid('', true) . '.' . $file_ext;
                $itr_destination = '../resources/uploads/' . $itr_name_new;

                if(move_uploaded_file($itr_tmp, $itr_destination)){
                    echo "File uploaded successfully.";
                }
            }
        }
    }
        //brgy_clearance
    if(in_array($brgy_clearance_ext, $allowed)){
        if($brgy_clearance_error === 0){
            if($brgy_clearance_size <= 2097152){
                $brgy_clearance_name_new = $name. '.' . $brgy_clearance_ext;//uniqid('', true) . '.' . $file_ext;
                $brgy_clearance_destination = '../resources/uploads/' . $brgy_clearance_name_new;

                if(move_uploaded_file($brgy_clearance_tmp, $brgy_clearance_destination)){
                    echo "File uploaded successfully.";
                }
            }
        }
    }
        //form138
    if(in_array($form138_ext, $allowed)){
        if($form138_error === 0){
            if($form138_size <= 2097152){
                $form138_name_new = $name. '.' . $form138_ext;//uniqid('', true) . '.' . $file_ext;
                $form138_destination = '../resources/uploads/' . $form138_name_new;

                if(move_uploaded_file($form138_tmp, $form138_destination)){
                    echo "File uploaded successfully.";
                }
            }
        }
    }
        //bills
    if(in_array($bills_ext, $allowed)){
        if($bills_error === 0){
            if($bills_size <= 2097152){
                $bills_name_new = $name. '.' . $bills_ext;//uniqid('', true) . '.' . $file_ext;
                $bills_destination = '../resources/uploads/' . $bills_name_new;

                if(move_uploaded_file($bills_tmp, $bills_destination)){
                    echo "File uploaded successfully.";
                }
            }
        }
    }
*/

        $lname = $_SESSION['lname'];
        $fname = $_SESSION['fname'];


        $name = $lname . $fname;

    if(isset($_FILES['files'])){
        foreach($_FILES['files']['tmp_name'] as $key => $tmp_name ){
            $file_name = $_FILES['files']['name'][$key];
            $file_size =$_FILES['files']['size'][$key];
            $file_tmp =$_FILES['files']['tmp_name'][$key];
            $file_type=$_FILES['files']['type'][$key];  
            if($file_size > 2097152){
                echo "File size must be less than 2 MB";
            }       
            $desired_dir='../resources/uploads/'.$name;
            if(is_dir($desired_dir)==false){
                mkdir("$desired_dir", 0700);        // Create directory if it does not exist
            }
            if(is_dir("$desired_dir/".$file_name)==false){
                move_uploaded_file($file_tmp,"$desired_dir/".$file_name);
            }else{                                  // rename the file if another one exist
                $new_dir="$desired_dir/".$file_name.time();
                 rename($file_tmp,$new_dir) ;               
            }
        }
        echo "Success";
    }

    echo "<script>window.close();</script>";

?>
