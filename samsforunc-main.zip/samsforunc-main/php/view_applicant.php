<?php

include 'conn.php';

session_start();


if(isset($_GET['applicantid'])){
$applicant_id = $_GET['applicantid'];
}
$sql = "SELECT *
        FROM applicants
        WHERE applicant_id ='$applicant_id';";

$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);

$application_date = $row['application_date'];
$lname = $row['lname'];
$fname = $row['fname'];
$mname = $row['mname'];
$student_number = $row['student_number'];
$course_year = $row['course_year'];
$civil_status = $row['civil_status'];
$citizenship = $row['citizenship'];
$gender = $row['gender'];
$religion = $row['religion'];
$contact_number = $row['contact_number'];
$naga_address = $row['naga_address'];
$naga = $row['naga'];
$permanent_address = $row['permanent_address'];
$fathers_name = $row['fathers_name'];
$fathers_age  = $row['fathers_age'];
$fathers_occupation = $row['fathers_occupation'];
$fathers_nai = $row['fathers_nai'];
$fathers_ha = $row['fathers_ha'];
$fathers_cn = $row['fathers_cn'];
$fathers_nca = $row['fathers_nca'];
$fcompany_cn = $row['fcompany_cn'];
$mothers_name = $row['mothers_name'];
$mothers_age = $row['mothers_age'];
$mothers_occupation = $row['mothers_occupation'];
$mothers_nai=  $row['mothers_nai'];
$mothers_ha = $row['mothers_ha'];
$mothers_cn = $row['mothers_cn'];
$mothers_nca = $row['mothers_nca'];
$mcompany_cn = $row['mcompany_cn'];
$siblings_name = $row['siblings_name'];
$siblings_age = $row['siblings_age'];
$siblings_sloc=  $row['siblings_sloc'];
$siblings_ppf=  $row['siblings_ppf'];
$total_siblings = $row['total_siblings'];
$number_working_siblings=  $row['number_working_siblings'];
$number_studying_siblings = $row['number_studying_siblings'];
$school  = $row['school'];
$school_location = $row['school_location'];
$reason = $row['reason'];
$org_name = $row['org_name'];
$org_position = $row['org_position'];

?> 

<style>

    table{
        text-align: center;
    }
</style>


<legend><b>Personal Data</b></legend><br>
<label for="lname">Application Date</label> <input type="text" name="lname" id="" value="<?php echo $application_date; ?>">
<label for="lname">Last Name</label> <input type="text" name="lname" id="" value="<?php echo $lname; ?>">
<label for="fname">Middle Name</label> <input type="text" name="fname" id="" value="<?php echo $mname; ?>">
<label for="mname">First Name</label> <input type="text" name="mname" id="" value="<?php echo $fname; ?>">

<br>
<hr>

<label for="student_number">Student Number</label> <input type="text" name="student_number" id="" value="<?php echo $student_number; ?>">
<label for="course_year">Course & Year</label> <input type="text" name="course_year" id="" value="<?php echo $course_year; ?>">
<label for="civil_status">Civil Status</label> <input type="text" name="civil_status" id="" value="<?php echo $civil_status; ?>">

<br>
<hr>

<label for="citizenship">Citizenship</label> <input type="text" name="citizenship" id="" value="<?php echo $citizenship; ?>">
<label for="gender">Gender</label> <input type="text" name="gender" id="" value="<?php echo $gender; ?>">
<label for="religion">Religion</label> <input type="text" name="religion" id="" value="<?php echo $religion; ?>"><br>
<label for="contact_number">Contact Number/s</label> <input type="text" name="contact_number" id="" value="<?php echo $contact_number; ?>">

<br><hr>

<label for="naga_address">Address in Naga City</label> <input type="text" name="naga_address" id="" style="width:500px;" value="<?php echo $naga_address; ?>"><br>
Residing at: &emsp; <input type="radio" name="naga" id="bhouse" value="Boarding House">Boarding House &emsp; 
<input type="radio" name="naga" id="phouse" value="Parent's House"> Parent's House &emsp; 
<input type="radio" name="naga" id="ghouse" value="With Guardian"> With Guardian 

<?php

if($naga==="Boarding House"){
    echo "<script>
    const naga= document.getElementById('bhouse');
    naga.setAttribute('checked', '');
    </script>";
}
else if($naga==="Parent's House"){
    echo "<script>
    const naga= document.getElementById('phouse');
    naga.setAttribute('checked', '');
    </script>";
}
else if($naga==="With Guardian"){
    echo "<script>
    const naga= document.getElementById('ghouse');
    naga.setAttribute('checked', '');
    </script>";
}

?>
<br><hr>

<label for="permanent_address">Permanent Address</label><input type="text" name="permanent_address" style="width:500px;" id="" value="<?php echo $permanent_address; ?>">

<br><hr><br>
<legend><b>Family Background</b></legend><br>

<label for="fathers_name">Father's Name</label> <input type="text" name="fathers_name" id="" value="<?php echo $fathers_name; ?>">
<label for="fathers_age">Age</label> <input type="text" name="fathers_age" id="" value="<?php echo $fathers_age; ?>">

<br><hr>

<label for="fathers_occupation">Occupation</label><input type="text" name="fathers_occupation" id="" value="<?php echo $fathers_occupation; ?>">
<label for="fathers_nai">Net Annual Income</label><input type="text" name="fathers_nai" id="" value="<?php echo $fathers_nai; ?>">

<br><hr>

<label for="fathers_ha">Home Address</label> <input type="text" name="fathers_ha" id="" value="<?php echo $fathers_ha; ?>">
<label for="fathers_cn">Contact Number/s</label> <input type="text" name="fathers_cn" id="" value="<?php echo $fathers_cn; ?>">
<br><hr>

<label for="fathers_nca">Name of Company / Address</label> <input type="text" name="fathers_nca" id="" value="<?php echo $fathers_nca; ?>">
<label for="fcompany_cn">Contact Number/s</label> <input type="text" name="fcompany_cn" id="" value="<?php echo $fcompany_cn; ?>">

<br><hr>

<label for="mothers_name">Mother's Name</label> <input type="text" name="mothers_name" id="" value="<?php echo $mothers_name; ?>">
<label for="mothers_age">Age</label> <input type="text" name="mothers_age" id="" value="<?php echo $mothers_age; ?>">

<br><hr>

<label for="mothers_occupation">Occupation</label><input type="text" name="mothers_occupation" id="" value="<?php echo $mothers_occupation; ?>">
<label for="mothers_nai">Net Annual Income</label><input type="text" name="mothers_nai" id="" value="<?php echo $mothers_nai; ?>">

<br><hr>

<label for="mothers_ha">Home Address</label> <input type="text" name="mothers_ha" id="" value="<?php echo $mothers_ha; ?>">
<label for="mothers_cn">Contact Number/s</label> <input type="text" name="mothers_cn" id="" value="<?php echo $mothers_ha; ?>">
<br><hr>

<label for="mothers_nca">Name of Company / Address</label> <input type="text" name="mothers_nca" id="" value="<?php echo $mothers_nca; ?>">
<label for="mcompany_cn">Contact Number/s</label> <input type="text" name="mcompany_cn" id="" value="<?php echo $mcompany_cn; ?>">

<br><hr><br>
<label for="siblings_table"></label><br>
<table name="siblings_table">
    <thead>
        <th>Name</th>
        <th>Age</th>
        <th>School/Location/Occupation/Company</th>
        <th>Program Presently Taking / Finished</th>
    </thead>

    <tbody>
    <tr>
        <td><input type="text" name="name1" id="namee1" value=""></td>
        <td><input type="text" name="age1" id="age1"></td>
        <td><input type="text" name="sloc1" id="sloc1"></td>
        <td><input type="text" name="ppf1" id="ppf1"></td>
    </tr>
    <tr>
        <td><input type="text" name="name2" id="namee2"></td>
        <td><input type="text" name="age2" id="age2"></td>
        <td><input type="text" name="sloc2" id="sloc2"></td>
        <td><input type="text" name="ppf2" id="ppf2"></td>
    </tr>
    <tr>
        <td><input type="text" name="name3" id="namee3"></td>
        <td><input type="text" name="age3" id="age3"></td>
        <td><input type="text" name="sloc3" id="sloc3"></td>
        <td><input type="text" name="ppf3" id="ppf3"></td>
    </tr>
    <tr>
        <td><input type="text" name="name4" id="namee4"></td>
        <td><input type="text" name="age4" id="age4"></td>
        <td><input type="text" name="sloc4" id="sloc4"></td>
        <td><input type="text" name="ppf4" id="ppf4"></td>
    </tr>
    <tr>
        <td><input type="text" name="name5" id="namee5"></td>
        <td><input type="text" name="age5" id="age5"></td>
        <td><input type="text" name="sloc5" id="sloc5"></td>
        <td><input type="text" name="ppf5" id="ppf5"></td>
    </tr>
    <tr>
        <td><input type="text" name="name6" id="namee6"></td>
        <td><input type="text" name="age6" id="age6"></td>
        <td><input type="text" name="sloc6" id="sloc6"></td>
        <td><input type="text" name="ppf6" id="ppf6"></td>
    </tr>
    <tr>
        <td><input type="text" name="name7" id="namee7"></td>
        <td><input type="text" name="age7" id="age7"></td>
        <td><input type="text" name="sloc7" id="sloc7"></td>
        <td><input type="text" name="ppf7" id="ppf7"></td>
    </tr>
    <tr>
        <td><input type="text" name="name8" id="namee8"></td>
        <td><input type="text" name="age8" id="age8"></td>
        <td><input type="text" name="sloc8" id="sloc8"></td>
        <td><input type="text" name="ppf8" id="ppf8"></td>
    </tr>
    <tr>
        <td><input type="text" name="name9" id="namee9"></td>
        <td><input type="text" name="age9" id="age9"></td>
        <td><input type="text" name="sloc9" id="sloc9"></td>
        <td><input type="text" name="ppf9" id="ppf9"></td>
    </tr>
    <tr>
        <td><input type="text" name="name10" id="namee10"></td>
        <td><input type="text" name="age10" id="age10"></td>
        <td><input type="text" name="sloc10" id="sloc10"></td>
        <td><input type="text" name="ppf10" id="ppf10"></td>
    </tr>
    </tbody>
</table>

<?php  

$siblings_name_arr = explode(",", $siblings_name);
$siblings_age_arr = explode(",", $siblings_age);
//$siblings_sloc_arr = explode(",", $siblings_sloc);
//$siblings_ppf_arr = explode(",", $siblings_ppf);

$siblings_name_arr_count = count($siblings_name_arr);
$siblings_age_arr_count = count($siblings_age_arr);
//$siblings_sloc_arr_count = count($siblings_sloc_arr);
//$siblings_ppf_arr_count = count($siblings_ppf_arr);

for ( $i = 1; $i<=$siblings_name_arr_count; $i++){
   $index = $i-1;
    echo "<script>
    var namee = document.getElementById('namee$i');
   
    namee.value = '$siblings_name_arr[$index]';
    
    </script>";
    echo " <script>
    var age = document.getElementById('age$i');
  
    age.value = '$siblings_age_arr[$index]';
   
  
    </script>";

}



?>

<br><hr>

<label for="total_siblings">Total Number of Sibling/s:</label> <input type="text" name="total_siblings" id="">
<label for="number_working_siblings">Number of Working Sibling/s</label> <input type="text" name="number_working_siblings" id="">
<br><label for="number_studying_siblings">Number of Studying Sibling/s</label> <input type="text" name="number_studying_siblings" id="">

<br><hr><br>

<legend><b>School Last Attended</b></legend><br>
<label for="school">School</label> <input type="text" name="school" id="">
<label for="school_location">Location of School</label> <input type="text" name="school_location " id="">

<br><hr>
<label for="honors">Honors / Awards Received</label> <input type="text" name="honors" id="">
<label for="general_average">General Average</label><input type="text" name="general_average" id="">

<br><hr>
<label for="reason">Reason/s for availing student assistantship:</label><br>
<textarea name="reason" style="width:700px;height:50px;"id=""></textarea>

<br><hr>
<label for="orgs">Current Membership in Organizations (in UNC and off-campus)/ Extra Curricular Activities:</label><br>
<label for="#org_name">Name of Organization/s</label> &emsp; <label for="position">Position</label><br>

<input type="text" name="orgname1" id="org_name">&emsp;&emsp;<input type="text" name="pos1" id="#position"><br>
<input type="text" name="orgname2" id="org_name">&emsp;&emsp;<input type="text" name="pos2" id="#position"><br>
<input type="text" name="orgname3" id="org_name">&emsp;&emsp;<input type="text" name="pos3" id="#position">
<br><hr><br>


