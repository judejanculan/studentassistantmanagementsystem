<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
   

<style>

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    border: 1px solid black;
    padding: 8px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

</style>

<table>
<thead>
<th>SA id</th>
<th>Student Number</th>
<th>Name</th>
<th>Actions</th>


</thead>

<tbody>


<?php

include 'conn.php';
session_start();


$username = $_SESSION['username'];

$sql = "SELECT * 
        FROM departments
        WHERE username = '$username';";

$result = mysqli_query($con, $sql);

$row = mysqli_fetch_array($result);

$dept_id = $row['dept_id'];
$_SESSION['dept_id'] = $dept_id;
$sql = "SELECT *
        FROM studentassistants
        WHERE dept_id = '$dept_id';";

$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_array($result)){
    $sa_id = $row['sa_id'];
    $student_id = $row['student_id'];
    $name = $row['name'];

   
   

    echo "
    <tr>
    <th scope='row'>$sa_id</th>
    <td>$student_id</td>
    <td>$name</td>
    <td><button class ='btn btn-primary'><a href='rate.php?sa_id=$sa_id'
    class='text-light'>Evaluate</a></button></td>
    </tr>";
}


?>

</tbody>

</table>