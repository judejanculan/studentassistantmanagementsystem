<?php

include 'conn.php';

session_start();

$username = $_SESSION['username'];
$loginas = $_SESSION['loginas'];



if($loginas ==="hr"){
$sql = "SELECT *
        FROM admin
        WHERE username = '$username';";
}
else if($loginas ==="sgo"){
    $sql = "SELECT *
            FROM sgo
            WHERE username = '$username';";
}
else if($loginas ==="dept"){
    $sql = "SELECT *
            FROM departments
            WHERE username = '$username';";
}
else if($loginas ==="sa"){
    $sql = "SELECT *
            FROM studentassistants
            WHERE username = '$username';";
}

$result = mysqli_query($con,$sql);

$row = mysqli_fetch_assoc($result);
$password = $row['password'];

if(isset($_POST['newusername'])){
$newusername = $_POST['newusername'];
}
if(isset($_POST['newpassword'])){
$newpassword = $_POST['newpassword'];
}

if(isset($_POST['submit'])){
    if($loginas ==="hr"){
        $sql = "UPDATE `admin`
                SET username='$newusername',
                `password`='$newpassword'
                WHERE username='$username';";
        }
        else if($loginas ==="sgo"){
            $sql = "UPDATE `sgo`
            SET username='$newusername',
            `password`='$newpassword'
            WHERE username='$username';";
        }
        else if($loginas ==="dept"){
            $sql = "UPDATE `departments`
            SET username='$newusername',
            `password`='$newpassword'
            WHERE username='$username';";
        }
        else if($loginas ==="sa"){
            $sql = "UPDATE `studentassistants`
            SET username='$newusername',
            `password`='$newpassword'
            WHERE username='$username';";
        }

        $result = mysqli_query($con, $sql);

        if($result){
            header("Location:profile.php");
        }
        else{
            die(mysqli_error($con));
        }
}

?>

<!doctype html>
<html>
    <head></head>
    
    <body>
        
    
    <div>Profile
<form method="POST">
<br><label for="username">Username</label>
<input type="text" name="newusername" value="<?php echo $username ?>">
<br><label for="password">Password</label>
<input type="text" name="newpassword" value="<?php echo $password ?>">

</div>

<div>
    <button class="btn btn-primary" type ="submit" name="submit">Save</button>
</form>
</div>

</body>

</html>
