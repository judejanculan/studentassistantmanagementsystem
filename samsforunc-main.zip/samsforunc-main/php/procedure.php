<ul>

<li>Fill out application form</li>
<li>Submit all requirements</li>
<li>Take examination</li>
<li>Interview</li>
<li>Medical exam</li>
<li>Get endorsed by HR</li>
</ul>

