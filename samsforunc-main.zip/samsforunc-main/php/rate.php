<style>

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    border: 1px solid black;
    padding: 8px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

</style>

<?php

include 'conn.php';

session_start();

$sa_id = $_GET['sa_id'];
$_SESSION['sa_id'] = $sa_id;

?>


<form action="compute.php" method="post" target="_blank">
<table>
    <thead>
        <th>Characteristic</th>
        <th>1</th>
        <th>2</th>
        <th>3</th>
        <th>4</th>
        <th>5</th>
    </thead>


    <tbody>
        <tr><td><b>Attitude</b> 
        <p>Maintains employee and provide task and manners and understandable</p> </td>
        <td><input type="radio" name="attitude" value="1"></td>
        <td><input type="radio" name="attitude" value="2"></td>
        <td><input type="radio" name="attitude" value="3"></td>
        <td><input type="radio" name="attitude" value="4"></td>
        <td><input type="radio" name="attitude" value="5"></td>
    </tr>

    <tr><td><b>Confidentiality</b>
               <p>Maintains confidentiality of departmental records.</p> </td>
        <td><input type="radio" name="confidentiality" value="1"></td>
        <td><input type="radio" name="confidentiality" value="2"></td>
        <td><input type="radio" name="confidentiality" value="3"></td>
        <td><input type="radio" name="confidentiality" value="4"></td>
        <td><input type="radio" name="confidentiality" value="5"></td>
    </tr>

    <tr><td><b>Quality of Work</b>
       <p>Comments work accurately and thoroughly</p> </td>
        <td><input type="radio" name="quality_of_work" value="1"></td>
        <td><input type="radio" name="quality_of_work" value="2"></td>
        <td><input type="radio" name="quality_of_work" value="3"></td>
        <td><input type="radio" name="quality_of_work" value="4"></td>
        <td><input type="radio" name="quality_of_work" value="5"></td>
    </tr>

    <tr><td><b>Dependability</b>
         <p>Arrives to work on time and completes assigned tasks</p> </td>
        <td><input type="radio" name="dependability" value="1"></td>
        <td><input type="radio" name="dependability" value="2"></td>
        <td><input type="radio" name="dependability" value="3"></td>
        <td><input type="radio" name="dependability" value="4"></td>
        <td><input type="radio" name="dependability" value="5"></td>
    </tr>

    <tr><td><b>Communication</b>
            <p>Demonstrates effective verbal and written communication skills </p> </td>
        <td><input type="radio" name="communication" value="1"></td>
        <td><input type="radio" name="communication" value="2"></td>
        <td><input type="radio" name="communication" value="3"></td>
        <td><input type="radio" name="communication" value="4"></td>
        <td><input type="radio" name="communication" value="5"></td>
    </tr>
    </tbody>
</table>

<input type="submit" value="Done" >

</form>