<?php

include 'conn.php';
session_start();

$sa_id = $_SESSION['sa_id'];
$dept_id = $_SESSION['dept_id'];

$attitude = $_POST['attitude'];
$confidentiality = $_POST['confidentiality'];
$quality_of_work = $_POST['quality_of_work'];
$dependability =  $_POST['dependability'];
$communication = $_POST['communication'];

$attitude = $attitude *20;
$confidentiality =  $confidentiality*20;
$quality_of_work = $quality_of_work*20;
$dependability =  $dependability*20;
$communication = $communication*20;


$average = (($attitude+$confidentiality+$quality_of_work+$communication+$dependability)/5);

$sql = "INSERT INTO `evaluations` 
(`eval_id`, `sa_id`, `dept_id`, `criteria1`, `criteria2`, `criteria3`, `criteria4`, `criteria5`, `average`)
 VALUES (NULL, '$sa_id','$dept_id','$attitude','$confidentiality','$quality_of_work','$dependability'
 ,'$communication','$average');";

 $result = mysqli_query($con,$sql);

 if(!$result){
    echo "Error";
 }

 echo "<script>window.close();</script>";
?>