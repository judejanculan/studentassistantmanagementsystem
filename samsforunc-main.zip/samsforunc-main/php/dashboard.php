<style>
    .row{
        text-align: center;
    }
    #active_sa{
        width:50%;
        background-color:green;
        height:100px;
        position:relative;
        float:left;
    }
    #unendorsed{
        width:50%;
        background-color:yellow;
        float:right;
        height:100px;
        position: relative;
    }
    #timed_in{
        width:50%;
        background-color:orange;
        height:100px;
        position:relative;
        float:left;
    }
    #evaluated{
        width:50%;
        background-color:lightblue;
        float:right;
        height:100px;
        position: relative;
    }
</style>

            <?php

            include 'conn.php';

            session_start();

           
            $loginas = $_SESSION['loginas'];
             
            if($loginas === "hr"){


            }
            else if($loginas === "sgo"){

            }
            else if($loginas === "dept"){
                $dept_id = $_SESSION['dept_id'];
            }
            else if($loginas === "sa"){

            }


            $sql = "SELECT * 
                    FROM studentassistants
                    WHERE sa_status = 'active';";

            $result = mysqli_query($con, $sql);

           $active_sa = mysqli_num_rows($result);

           $sql = "SELECT *
                    FROM studentassistants
                    WHERE sa_status = 'not endorsed';";
            $result = mysqli_query($con, $sql);

            $unendorsed = mysqli_num_rows($result);

            


            $now = new DateTime();
$now ->setTimezone(new DateTimeZone('Asia/Manila'));

$date_now = $now->format('Y-m-d');



$sql = "SELECT * 
        FROM evaluations;";

$result = mysqli_query($con,$sql);

$evaluated = mysqli_num_rows($result);


$sql="SELECT *
    FROM dtrs
    WHERE `date` = '$date_now'
    AND `time_in` != '';";

$result = mysqli_query($con,$sql);

$timed_in = mysqli_num_rows($result);


            if ($loginas==="hr"){
                
                echo " <div class='row'>
                <div class='col' id ='active_sa'>
                    <h3>Active SA</h3><br>
                $active_sa
                </div>
                <div class='col order-12' id='unendorsed'>

                <h3>Unendorsed SA</h3><br>
               $unendorsed
                  </div>
            </div>
            
            <div class='row'>
                <div class='col' id='timed_in'>
                    <h3>Timed in SA</h3><br>
                 $timed_in
                </div>
                <div class='col order-12' id='evaluated'>
                    <h3>Evaluated SA</h3><br>
                    $evaluated
                </div>
            </div>
            ";

            }

            else if($loginas==="dept"){
                $sql = "SELECT * 
                FROM evaluations
                WHERE dept_id = '$dept_id';";
        
        $result = mysqli_query($con,$sql);
        
        $dept_evaluated = mysqli_num_rows($result);

        $sql="SELECT *
    FROM dtrs
    WHERE `date` = '$date_now'
    AND `time_in` != ''
    AND `dept_id` = '$dept_id';";

$result = mysqli_query($con,$sql);

$timed_in_dept = mysqli_num_rows($result);


                echo "
        
        
        <div class='row'>
            <div class='col' id='timed_in'>
                <h3>Timed in SA in my Department</h3><br>
                $timed_in_dept
            </div>
            <div class='col order-12' id='evaluated'>
                <h3>Evaluated SA in my Department</h3><br>
                $dept_evaluated
            </div>
        </div>

        <table>
        <thead>
        <th>sa_id</th>
        <th>Name</th></thead>
        <tbody>
        
        ";

      
        $sql = "SELECT * 
                FROM studentassistants
                WHERE dept_id = '$dept_id'";

        $result = mysqli_query($con, $sql);

        while ($row = mysqli_fetch_array($result)){

            $sa_id = $row['sa_id'];
            $name = $row['name'];

                echo "
            <tr>
            <td>$sa_id</td>
            <td>$name</td>
            </tr>";
        }

        
        
        echo "</tbody></table>";

}

        else if ($loginas==="sgo"){

            $sql = "SELECT *
            FROM applicants
            WHERE application_date = '$date_now'";
    $result = mysqli_query($con,$sql);
    $applications_today = mysqli_num_rows($result);

    $sql = "SELECT *
            FROM applicants;";
    $result = mysqli_query($con,$sql);
    
    $applicants = mysqli_num_rows($result);
          
        echo "
        <div class='row'>
            <div class='col' id='timed_in'>
                <h3>Applicants</h3><br>
             $applicants
            </div>
            <div class='col order-12' id='evaluated'>
                <h3>Applicants Today</h3><br>
                $applications_today
            </div>
        </div>";

        }



            ?>