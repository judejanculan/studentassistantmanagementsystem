<?php

session_start();

$sa_id = $_SESSION['sa_id'];

?>

<head><style>
#timein{

    margin: auto;
  width: 50%;

  padding: 10px
}
#timeout{

margin: auto;
width: 50%;

padding: 10px;
float:right;
}

</style></head>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">


<button type="button" class="btn btn-primary" id="timein"><a href="timein.php" target="_blank" class="text-light">Time In</a></button>
<button type="button" class="btn btn-danger" id="timeout" disabled><a href="timeout.php" target="_blank" class="text-light">Time Out</a></button>


<script>
    document.getElementById("timein").addEventListener("click", function() {
  // code to disable second link goes here

  document.getElementById("timein").setAttribute("disabled", true);
 document.getElementById("timeout").removeAttribute("disabled");
 
});

document.getElementById("timeout").addEventListener("click", function() {
  // code to disable second link goes here
  document.getElementById("timeout").setAttribute("disabled", true);
  document.getElementById("timein").removeAttribute("disabled");
});

</script>