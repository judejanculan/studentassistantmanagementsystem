<style>

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    border: 1px solid black;
    padding: 8px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

</style>
<table>
    <thead>
        <th>Applicant ID</th>
        <th>Student Number</th>
        <th>Name</th>
        <th>Actions</th>
    </thead>
    
    <tbody>
        

        <?php

        include 'conn.php';

        $sql = "SELECT *
                FROM applications;";
        $result = mysqli_query($con, $sql);

        while ($row = mysqli_fetch_array($result)){

            $applicant_id = $row['applicant_id'];
            $student_number = $row['student_number'];
            $name = $row['name'];

            echo "
            <tr>
            <th scope='row'>$applicant_id</th>
            <td>$student_number</td>
            <td>$name</td>
            <td><button class='btn btn-primary'><a href='view_applicant.php?applicantid=$applicant_id' class='text-light'>View
            </a></button></td>
            
            </tr>
            ";
        }

        ?>
        
    </tbody>
</table>