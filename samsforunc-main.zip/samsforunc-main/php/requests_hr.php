<table>
    <thead><th>Department</th>
<th>Number of SA needed</th>
<th>Preferred Course</th>
<th>Comment</th></thead>

<tbody>


<?php

include 'conn.php';

session_start();

$sql = "SELECT * 
        FROM requests;";

$result = mysqli_query($con,$sql);

while ($row = mysqli_fetch_assoc($result)){
    $dept_id = $row['dept_id'];
    $number_of_sa = $row['number_of_sa'];
    $preferred_course = $row['preferred_course'];
    $comment = $row['comment'];

    $sql2 = "SELECT * 
            FROM departments
            WHERE dept_id = '$dept_id';";
    $result2 = mysqli_query($con, $sql2);
    $row2 = mysqli_fetch_assoc($result2);

    $dept_name = $row2['dept_name'];
    echo
    "<tr>
    <td>$dept_name</td>
    <td>$number_of_sa</td>
    <td>$preferred_course</td>
    <td>$comment</td>
    </tr>
    ";
}


?>
</tbody>
</table>