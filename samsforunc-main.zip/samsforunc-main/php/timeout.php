<?php 

include 'conn.php';
session_start();

$sa_id = $_SESSION['sa_id'];
$now = new DateTime();
$now ->setTimezone(new DateTimeZone('Asia/Manila'));
$date = $now->format('Y-m-d');

$current_time = $now->format('H:i');
$sql = "UPDATE `dtrs` 
        SET `time_out` = '$current_time'
        WHERE sa_id = '$sa_id'
        AND `date` = '$date'
        AND time_out = '';";

$result = mysqli_query($con, $sql);


echo "<script>window.close();</script>";
?>



