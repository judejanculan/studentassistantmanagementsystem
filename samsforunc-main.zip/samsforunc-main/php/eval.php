<style>

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    border: 1px solid black;
    padding: 8px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

</style>

<?php

include 'conn.php';

?>

<table class="table">

<thead>
<tr>
<th scope="col">SA_id</th>
<th scope="col">Student Number</th>
<th scope="col">Name</th>
<th scope="col">Average</th>
<th scope="col">Actions</th>

</tr>
</thead>

<tbody>

<?php

$sql =  "SELECT *
        FROM evaluations";

$result = mysqli_query($con,$sql);

if ($result){
    while ($row = mysqli_fetch_array($result)){
    $sa_id=$row['sa_id'];

    


            $sql2="SELECT *
                    FROM studentassistants 
                    WHERE sa_id =$sa_id";

            $result2= mysqli_query($con,$sql2);
            $row2= mysqli_fetch_array($result2);

    $student_number = $row2['student_id'];
    $name= $row2['name'];
    $average = $row['average'];

   
    echo " <tr>

    <th scope='row'>$sa_id</th>
    <td>$student_number</td>
    <td>$name</td>
    <td>$average</td>
    <td><button class='btn btn-primary'><a href='radar.php?id=$sa_id' class='text-light'>Show</a></button></td>
    
    </tr>
    ";

        }

}


?>

</tbody>

</table>