<?php
include 'conn.php';




?>


<div class="float-lg-right" id="content">
<!--sample-->
<iframe src="under.html"  name="content" id="content" width=900 height=400></iframe>

</div>



<div class="row" id="aside">
  <ul class="list-group list-group-flush rounded-3" id="menu">

  <li class="list-group-item d-flex align-items-center transparent p-3"><div class="mb-0">
              <a class="link" href="php/dashboard.php" target="content" >&nbsp;&nbsp;&nbsp;Dashboard</a></div></li>
   
          <li class="list-group-item d-flex align-items-center transparent p-3"><div class="mb-0">
              <a class="link" href="php/profile.php" target="content" >&nbsp;&nbsp;&nbsp;Profile</a></div></li>
              
              <li class="list-group-item d-flex align-items-center transparent p-3"><div class="mb-0"><a class="link"
              href="php/request.php" target="content" >
                &nbsp;&nbsp;&nbsp;Request SA</a></div></li>

             <!--   <li class="list-group-item d-flex align-items-center transparent p-3">
                  <div class="mb-0"><a class="link" href="under.html" target="content" >&nbsp;&nbsp;&nbsp;
                  Scheduling</a></div></li>

                  
                <li class="list-group-item d-flex align-items-center transparent p-3">
                  <div class="mb-0"><a class="link" href="php/dtr.php" target="content" >&nbsp;&nbsp;&nbsp;
                  Attendance</a></div></li>


                  <li class="list-group-item d-flex align-items-center transparent p-3">  
                  <div class="mb-0">
                    <a class="link" href="under.html" target="content" >&nbsp;&nbsp;&nbsp;Student Assistants</a>
                  </div></li> -->
                  
                  <li class="list-group-item d-flex align-items-center transparent p-3">
                    <div class="mb-0">
                      <a  id="evaluation" href="php/evaluatee.php" target="content" >&nbsp;&nbsp;&nbsp;Evaluate</a>
                    </div></li>

                    
                    
                    
                    <li class="list-group-item d-flex align-items-center transparent p-3">
                    
                    <div class="mb-0"><a class="link" href="php/logout.php" >&nbsp;Logout</a><div class="Toastify">

                       </div></div></li></ul></div>
