<html><head>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.3/dist/Chart.min.js"></script>
</head>
<body>
   <canvas id="radarChart" width="200" height="50"></canvas>

    <?php 

    include 'conn.php';
    session_start();
    $sa_id = $_GET['id'];

    $sql = "SELECT *
            FROM evaluations
            WHERE sa_id = '$sa_id'";

    $result = mysqli_query($con,$sql);
    $row = mysqli_fetch_array($result);

    $criteria1 = $row['criteria1'];
    $criteria2 = $row['criteria2'];
    $criteria3 = $row['criteria3'];
    $criteria4 = $row['criteria4'];
    $criteria5 = $row['criteria5'];

    $average = $row['average'];

    $data = array(
        array("label" => "Attitude", "value" => $criteria1),
        array("label" => "Confidentiality", "value" => $criteria2),
        array("label" => "Quality of Work", "value" => $criteria3),
        array("label" => "Dependability", "value" => $criteria4),
        array("label" => "Communication", "value" => $criteria5)
    ); 
    
    ?>



    <script>
        // Get the canvas element
        var ctx = document.getElementById('radarChart').getContext('2d');
    
        // Create the chart
        var chart = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: [<?php foreach($data as $d) echo '"' . $d['label'] . '",'; ?>],
                datasets: [{
                    label: 'My Radar Chart',
                    data: [<?php foreach($data as $d) echo $d['value'] . ','; ?>],
                    backgroundColor: 'rgba(153, 102, 255, 0.2)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 1
                }]
            },
            options: {}
        });
    </script>

    <?php
        
            if ($average >=90){
             echo   "<h6>Highly recommended for renewal</h6>";
            }
            else if($average>=80){
        echo "<h6>Likely recommended for renewal</h6>";
            }
            else{
                echo "<h6>Not recommended for renewal</h6>";
            }

        ?>
</body>

</html>