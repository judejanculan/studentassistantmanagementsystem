<!DOCTYPE html>
<html>
<body>

<!--<form action="upload.php" method="post" enctype="multipart/form-data">
    Select file to upload: <br><hr>
    <input multiple type="file" name="pic" id="fileToUpload"><br>


   <input multiple type="file" name="itr" id="fileToUpload"><br>
   <input multiple type="file" name="brgy_clearance" id="fileToUpload"><br>
    <input multiple type="file" name="form138" id="fileToUpload"><br>

  <input multiple type="file" name="bills" id="fileToUpload">
<br>
    <input type="submit" value="submit" name="submit">
</form> -->

<form action="upload.php" method="post" enctype="multipart/form-data" target = "_blank">
2x2 Picture <br> Latest Income Tax Return of Parents or Certificate of Non-filling of Income Tax Return <br> 
Barangay Clearance <br> Photocopy of Grades / Form 138 <br> Photocopy of Water and Electric Bills for the last three months  <br>
<hr>
Select file to upload: <br>
    <input type="file" name="files[]" multiple>
    <input type="submit" value="Upload">
</form>

</body>
</html>