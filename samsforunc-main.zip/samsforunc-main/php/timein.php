<?php
include 'conn.php';

session_start();

$loginas= $_SESSION['loginas'];
$user_name =$_SESSION['username'] ;
$user_password =$_SESSION['password'] ;
 
$time_in = "";

$now = new DateTime();
$now ->setTimezone(new DateTimeZone('Asia/Manila'));
$current_time = $now->format('H:i');
$date = $now->format('Y-m-d');


$sql = "SELECT * 
        FROM studentassistants
        WHERE username = '$user_name';";

$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);

$sa_id = $row['sa_id'];

$name = $row['name'];


$sql2 = "INSERT INTO `dtrs` (`dtr_id`, `sa_id`, `name`, `dept_id`, `date`, `time_in`, `time_out`) 
        VALUES (NULL, '$sa_id', '$name' , '1', '$date', '$current_time', '');";

$result2 = mysqli_query($con,$sql2);

echo "<script>window.close();</script>";
?>