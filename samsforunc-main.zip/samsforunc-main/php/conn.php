<?php

$con = new mysqli('localhost','root','','sams');

if(!$con){
    echo "Error";
}


?>