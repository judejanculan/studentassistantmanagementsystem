<style>

    table{
        text-align: center;
    }
</style>

<form action="process_application.php" method="post" target="_blank">
<legend><b>Personal Data</b></legend><br>

<label for="lname">Last Name</label> <input type="text" name="lname" id="">
<label for="fname">Middle Name</label> <input type="text" name="fname" id="">
<label for="mname">First Name</label> <input type="text" name="mname" id="">

<br>
<hr>

<label for="student_number">Student Number</label> <input type="text" name="student_number" id="">
<label for="course_year">Course & Year</label> <input type="text" name="course_year" id="">
<label for="civil_status">Civil Status</label> <input type="text" name="civil_status" id="">

<br>
<hr>

<label for="citizenship">Citizenship</label> <input type="text" name="citizenship" id="">
<label for="gender">Gender</label> <input type="text" name="gender" id="">
<label for="religion">Religion</label> <input type="text" name="religion" id=""><br>
<label for="contact_number">Contact Number/s</label> <input type="text" name="contact_number" id="">

<br><hr>

<label for="naga_address">Address in Naga City</label> <input type="text" name="naga_address" id="" style="width:500px;"><br>
Residing at: &emsp; <input type="radio" name="naga" id="" value="Boarding House">Boarding House &emsp; 
<input type="radio" name="naga" id="" value="Parent's House "> Parent's House &emsp; 
<input type="radio" name="naga" id="" value="With Guardian "> With Guardian 

<br><hr>

<label for="permanent_address">Permanent Address</label><input type="text" name="permanent_address" style="width:500px;" id="">

<br><hr><br>
<legend><b>Family Background</b></legend><br>

<label for="fathers_name">Father's Name</label> <input type="text" name="fathers_name" id="">
<label for="fathers_age">Age</label> <input type="text" name="fathers_age" id="">

<br><hr>

<label for="fathers_occupation">Occupation</label><input type="text" name="fathers_occupation" id="">
<label for="fathers_nai">Net Annual Income</label><input type="text" name="fathers_nai" id="">

<br><hr>

<label for="fathers_ha">Home Address</label> <input type="text" name="fathers_ha" id="">
<label for="fathers_cn">Contact Number/s</label> <input type="text" name="fathers_cn" id="">
<br><hr>

<label for="fathers_nca">Name of Company / Address</label> <input type="text" name="fathers_nca" id="">
<label for="fcompany_cn">Contact Number/s</label> <input type="text" name="fcompany_cn" id="">

<br><hr>

<label for="mothers_name">Mother's Name</label> <input type="text" name="mothers_name" id="">
<label for="mothers_age">Age</label> <input type="text" name="mothers_age" id="">

<br><hr>

<label for="mothers_occupation">Occupation</label><input type="text" name="mothers_occupation" id="">
<label for="mothers_nai">Net Annual Income</label><input type="text" name="mothers_nai" id="">

<br><hr>

<label for="mothers_ha">Home Address</label> <input type="text" name="mothers_ha" id="">
<label for="mothers_cn">Contact Number/s</label> <input type="text" name="mothers_cn" id="">
<br><hr>

<label for="mothers_nca">Name of Company / Address</label> <input type="text" name="mothers_nca" id="">
<label for="mcompany_cn">Contact Number/s</label> <input type="text" name="mcompany_cn" id="">

<br><hr><br>
<label for="siblings_table"></label><br>
<table name="siblings_table">
    <thead>
        <th>Name</th>
        <th>Age</th>
        <th>School/Location/Occupation/Company</th>
        <th>Program Presently Taking / Finished</th>
    </thead>

    <tbody>
    <tr>
        <td><input type="text" name="name1" id=""></td>
        <td><input type="text" name="age1" id=""></td>
        <td><input type="text" name="sloc1" id=""></td>
        <td><input type="text" name="ppf1" id=""></td>
    </tr>
    <tr>
        <td><input type="text" name="name2" id=""></td>
        <td><input type="text" name="age2" id=""></td>
        <td><input type="text" name="sloc2" id=""></td>
        <td><input type="text" name="ppf2" id=""></td>
    </tr>
    <tr>
        <td><input type="text" name="name3" id=""></td>
        <td><input type="text" name="age3" id=""></td>
        <td><input type="text" name="sloc3" id=""></td>
        <td><input type="text" name="ppf3" id=""></td>
    </tr>
    <tr>
        <td><input type="text" name="name4" id=""></td>
        <td><input type="text" name="age4" id=""></td>
        <td><input type="text" name="sloc4" id=""></td>
        <td><input type="text" name="ppf4" id=""></td>
    </tr>
    <tr>
        <td><input type="text" name="name5" id=""></td>
        <td><input type="text" name="age5" id=""></td>
        <td><input type="text" name="sloc5" id=""></td>
        <td><input type="text" name="ppf5" id=""></td>
    </tr>
    <tr>
        <td><input type="text" name="name6" id=""></td>
        <td><input type="text" name="age6" id=""></td>
        <td><input type="text" name="sloc6" id=""></td>
        <td><input type="text" name="ppf6" id=""></td>
    </tr>
    <tr>
        <td><input type="text" name="name7" id=""></td>
        <td><input type="text" name="age7" id=""></td>
        <td><input type="text" name="sloc7" id=""></td>
        <td><input type="text" name="ppf7" id=""></td>
    </tr>
    <tr>
        <td><input type="text" name="name8" id=""></td>
        <td><input type="text" name="age8" id=""></td>
        <td><input type="text" name="sloc8" id=""></td>
        <td><input type="text" name="ppf8" id=""></td>
    </tr>
    <tr>
        <td><input type="text" name="name9" id=""></td>
        <td><input type="text" name="age9" id=""></td>
        <td><input type="text" name="sloc9" id=""></td>
        <td><input type="text" name="ppf9" id=""></td>
    </tr>
    <tr>
        <td><input type="text" name="name10" id=""></td>
        <td><input type="text" name="age10" id=""></td>
        <td><input type="text" name="sloc10" id=""></td>
        <td><input type="text" name="ppf10" id=""></td>
    </tr>
    </tbody>
</table>

<br><hr>

<label for="total_siblings">Total Number of Sibling/s:</label> <input type="text" name="total_siblings" id="">
<label for="number_working_siblings">Number of Working Sibling/s</label> <input type="text" name="number_working_siblings" id="">
<br><label for="number_studying_siblings">Number of Studying Sibling/s</label> <input type="text" name="number_studying_siblings" id="">

<br><hr><br>

<legend><b>School Last Attended</b></legend><br>
<label for="school">School</label> <input type="text" name="school" id="">
<label for="school_location">Location of School</label> <input type="text" name="school_location " id="">

<br><hr>
<label for="honors">Honors / Awards Received</label> <input type="text" name="honors" id="">
<label for="general_average">General Average</label><input type="text" name="general_average" id="">

<br><hr>
<label for="reason">Reason/s for availing student assistantship:</label><br>
<textarea name="reason" style="width:700px;height:50px;"id=""></textarea>

<br><hr>
<label for="orgs">Current Membership in Organizations (in UNC and off-campus)/ Extra Curricular Activities:</label><br>
<label for="#org_name">Name of Organization/s</label> &emsp; <label for="position">Position</label><br>

<input type="text" name="orgname1" id="org_name">&emsp;&emsp;<input type="text" name="pos1" id="#position"><br>
<input type="text" name="orgname2" id="org_name">&emsp;&emsp;<input type="text" name="pos2" id="#position"><br>
<input type="text" name="orgname3" id="org_name">&emsp;&emsp;<input type="text" name="pos3" id="#position">
<br><hr><br>
<input type="submit" value="submit">

</form>