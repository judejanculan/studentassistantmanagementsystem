<html>
    <head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" 
    integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" 
    crossorigin="anonymous">
        
        <style>
        #header {
        top:0;
        z-index: 1;
        background-color: #f1f1f1;
        padding:10px;
        position: sticky;
        }
        #headerlogo{
            left:0;
            margin-left:0px;
        }
        #headerlabel{
            position:relative;
            text-align:center;
          
          
            font-size:20px;
         
        }

    </style></head>

<body>
    <div class="container-fluid" id="header">
        <div class="container" id="headerlogo">
        <img src="assets/greysams.png" width=150 height =100 alt="sams logo">
        </div>

        <!-- <div class="container" id="headerlabel">
            <p>SAMS FOR UNC</p>
        </div> -->
    </div>
</body>
    </html>