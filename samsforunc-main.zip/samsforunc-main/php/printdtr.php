<style>

table {
    border-collapse: collapse;
    width: 100%;
}

th, td {
    border: 1px solid black;
    padding: 8px;
    text-align: left;
}

th {
    background-color: #f2f2f2;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

</style>

<body onload="printpage()">

<script>
    function printpage() {
        window.print();
    }
</script>
    


<table>

<thead>
<tr>
<th scope="col">DTR id</th>
<th scope="col">SA id</th>
<th scope="col">Name</th>
<th scope="col">Department id</th>
<th scope="col">Date</th>
<th scope="col">Time In</th>
<th scope="col">Time Out</th>
</thead>
<tbody>


<?php

include 'conn.php';
session_start();

$name = $_GET['name'];

$sql = "SELECT *
        FROM dtrs
        WHERE name = '$name';";

$result = mysqli_query($con,$sql);

while($row = mysqli_fetch_array($result)){
$dtr_id = $row['dtr_id'];
$sa_id=$row['sa_id'];
$name = $row['name'];
$dept_id = $row['dept_id'];
$date = $row['date'];
$time_in = $row['time_in'];
$time_out = $row['time_out'];

echo " <tr>

<th scope='row'>$dtr_id</th>
<td>$sa_id</td>
<td>$name</td>
<td>$dept_id</td>
<td>$date</td>
<td>$time_in</td>
<td>$time_out</td>

</tr>

"; }
?>

</tbody>
</table>

</body>