<?php

include 'conn.php';

session_start();

/*$lname, $fname, $mname, $student_number, $course_year, $civil_status, $citizenship, $gender, $religion,
$contact_number, $naga_address, $naga, $permanent_address, $fathers_name, $fathers_age, $fathers_occupation,
$fathers_nai, $fathers_ha, $fathers_cn, $fathers_nca, $fcompany_cn, $mothers_name, $mothers_age, $mothers_occupation,
$mothers_nai, $mothers_ha, $mothers_cn, $mothers_nca, $mcompany_cn, $siblings_name, $siblings_age,
$siblings_sloc, $siblings_ppf, $total_siblings, $number_working_siblings, $number_studying_siblings,
$school, $school_location, $reason, $org_name, $org_position; */


$now = new DateTime();
$now ->setTimezone(new DateTimeZone('Asia/Manila'));

$date_now = $now->format('Y-m-d');

$lname = $_POST['lname'];
$fname = $_POST['fname'];
$mname = $_POST['mname'];
$student_number = $_POST['student_number'];
$course_year = $_POST['course_year'];
$civil_status = $_POST['civil_status'];
$citizenship = $_POST['citizenship'];
$gender = $_POST['gender'];
$religion = $_POST['religion'];
$contact_number = $_POST['contact_number'];
$naga_address = $_POST['naga_address'];
$naga = $_POST['naga'];
$permanent_address = $_POST['permanent_address'];
$fathers_name = $_POST['fathers_name'];
$fathers_age  = $_POST['fathers_age'];
$fathers_occupation = $_POST['fathers_occupation'];
$fathers_nai = $_POST['fathers_nai'];
$fathers_ha = $_POST['fathers_ha'];
$fathers_cn = $_POST['fathers_cn'];
$fathers_nca = $_POST['fathers_nca'];
$fcompany_cn = $_POST['fcompany_cn'];
$mothers_name = $_POST['mothers_name'];
$mothers_age = $_POST['mothers_age'];
$mothers_occupation = $_POST['mothers_occupation'];
$mothers_nai=  $_POST['mothers_nai'];
$mothers_ha = $_POST['mothers_ha'];
$mothers_cn = $_POST['mothers_cn'];
$mothers_nca = $_POST['mothers_nca'];
$mcompany_cn = $_POST['mcompany_cn'];

$siblings_name="";
$siblings_age ="";
$siblings_sloc=  "";
$siblings_ppf=  "";

if(isset($_POST['name1'])&& $_POST['name1']!=""){
    $siblings_name = $_POST['name1'];
    $siblings_age = $_POST['age1'];
    $siblings_sloc= $_POST['sloc1'];
    $siblings_ppf =  $_POST['ppf1'];
}

 if(isset($_POST['name2'])&& $_POST['name2']!=""){
    $siblings_name = $siblings_name . ",". $_POST['name2'];
    $siblings_age = $siblings_age . ",". $_POST['age2'];
    $siblings_sloc = $siblings_sloc . ",". $_POST['sloc2'];
    $siblings_ppf= $siblings_ppf . ",". $_POST['ppf2'];
}

if(isset($_POST['name3'])&& $_POST['name3']!=""){
    $siblings_name = $siblings_name . ",". $_POST['name3'];
    $siblings_age = $siblings_age . ",". $_POST['age3'];
    $siblings_sloc = $siblings_sloc . ",". $_POST['sloc3'];
    $siblings_ppf= $siblings_ppf . ",". $_POST['ppf3'];
}
if(isset($_POST['name4'])&& $_POST['name4']!=""){
    $siblings_name = $siblings_name . ",". $_POST['name4'];
    $siblings_age = $siblings_age . ",". $_POST['age4'];
    $siblings_sloc = $siblings_sloc . ",". $_POST['sloc4'];
    $siblings_ppf= $siblings_ppf . ",". $_POST['ppf4'];
}
if(isset($_POST['name5'])&& $_POST['name5']!=""){
    $siblings_name = $siblings_name . ",". $_POST['name5'];
    $siblings_age = $siblings_age . ",". $_POST['age5'];
    $siblings_sloc = $siblings_sloc . ",". $_POST['sloc5'];
    $siblings_ppf= $siblings_ppf . ",". $_POST['ppf5'];
}
if(isset($_POST['name6'])&& $_POST['name6']!=""){
    $siblings_name = $siblings_name . ",". $_POST['name6'];
    $siblings_age = $siblings_age . ",". $_POST['age6'];
    $siblings_sloc = $siblings_sloc . ",". $_POST['sloc6'];
    $siblings_ppf= $siblings_ppf . ",". $_POST['ppf6'];
}
if(isset($_POST['name7'])&& $_POST['name7']!=""){
    $siblings_name = $siblings_name . ",". $_POST['name7'];
    $siblings_age = $siblings_age . ",". $_POST['age7'];
    $siblings_sloc = $siblings_sloc . ",". $_POST['sloc7'];
    $siblings_ppf= $siblings_ppf . ",". $_POST['ppf7'];
}
if(isset($_POST['name8'])&& $_POST['name8']!=""){
    $siblings_name = $siblings_name . ",". $_POST['name8'];
    $siblings_age = $siblings_age . ",". $_POST['age8'];
    $siblings_sloc = $siblings_sloc . ",". $_POST['sloc8'];
    $siblings_ppf= $siblings_ppf . ",". $_POST['ppf8'];
}
if(isset($_POST['name9'])&& $_POST['name9']!=""){
    $siblings_name = $siblings_name . ",". $_POST['name9'];
    $siblings_age = $siblings_age . ",". $_POST['age9'];
    $siblings_sloc = $siblings_sloc . ",". $_POST['sloc9'];
    $siblings_ppf= $siblings_ppf . ",". $_POST['ppf9'];
}
if(isset($_POST['name10']) && $_POST['name10']!=""){
    $siblings_name = $siblings_name . ",". $_POST['name10'];
    $siblings_age = $siblings_age . ",". $_POST['age10'];
    $siblings_sloc = $siblings_sloc . ",". $_POST['sloc10'];
    $siblings_ppf= $siblings_ppf . ",". $_POST['ppf10'];
}




$total_siblings = $_POST['total_siblings'];
$number_working_siblings=  $_POST['number_working_siblings'];
$number_studying_siblings = $_POST['number_studying_siblings'];
$school  = $_POST['school'];
$school_location = $_POST['school_location'];
$reason = $_POST['reason'];
$org_name = $_POST['org_name'];
$org_position = $_POST['org_position'];

$_SESSION['lname'] = $lname;
$_SESSION['fname'] = $fname;

$name = $fname . ' ' . $mname . ' ' . $lname;

$sql = "INSERT INTO `applicants` 
(`applicant_id`, `application_date`, `lname`, `fname`, `mname`, `student_number`, `course_year`, `civil_status`, 
`citizenship`, `gender`, `religion`, `contact_number`, `naga_address`, `naga`, `permanent_address`,
 `fathers_name`, `fathers_age`, `fathers_occupation`, `fathers_nai`, `fathers_ha`, `fathers_cn`, 
 `fathers_nca`, `fcompany_cn`, `mothers_name`, `mothers_age`, `mothers_occupation`, `mothers_nai`,
  `mothers_ha`, `mothers_cn`, `mothers_nca`, `mcompany_cn`, `siblings_name`, `siblings_age`, 
  `siblings_sloc`, `siblings_ppf`, `total_siblings`, `number_working_siblings`, 
  `number_studying_siblings`, `school`, `school_location`, `reason`, `org_name`, `org_position`) 
  VALUES (NULL,'$date_now', '$lname', '$fname', '$mname', '$student_number', '$course_year', '$civil_status',
   '$citizenship', '$gender', '$religion', '$contact_number', '$naga_address', '$naga', '$permanent_address',
    '$fathers_name', '$fathers_age', '$fathers_occupation', '$fathers_nai', '$fathers_ha', '$fathers_cn',
     '$fathers_nca', '$fcompany_cn', '$mothers_name', '$mothers_age', '$mothers_occupation', '$mothers_nai', 
     '$mothers_ha', '$mothers_cn', '$mothers_nca', '$mcompany_cn', '$siblings_name', '$siblings_age', 
     '$siblings_sloc', '$siblings_ppf', '$total_siblings', '$number_working_siblings', '$number_studying_siblings',
      '$school', '$school_location', '$reason', '$org_name', '$org_position');";

$result = mysqli_query($con,$sql);

$sql = "SELECT * 
        FROM applicants
        WHERE `lname` = '$lname' AND `student_number` = '$student_number';";

$result = mysqli_query($con,$sql);

$row = mysqli_fetch_array($result);

$applicant_id = $row['applicant_id'];

if (!$result){
    echo "Error: ";
}

$sql = "INSERT INTO `applications` (`application_id`, `applicant_id`, `student_number`, `name`) 
VALUES (NULL, '$applicant_id', '$student_number', '$name')";

$result = mysqli_query($con, $sql);


echo "<script>window.close();</script>";
?>