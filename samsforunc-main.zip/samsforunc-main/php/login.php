<?php

session_start();
include 'conn.php';


if(isset($_POST['username']) && $_POST['password']){
    $loginas = $_POST['loginas'];
    $username = $_POST['username'];
    $password= $_POST['password'];

    if(empty($username)){
        header("Location:index.php?error=Email is required");
    }
    else if(empty($password)){
        header("Location:index.php?error=Password is required");
    }
    else{
        if($loginas==="hr"){
            $sql = "SELECT *
                FROM admin
                wHERE username='$username';";
        }
        else if ($loginas==="sa"){
            $sql = "SELECT *
                FROM studentassistants
                wHERE username='$username';";
        }
        else if ($loginas==="sgo"){
            $sql = "SELECT *
                FROM sgo
                wHERE username='$username';";
        }
        else if ($loginas==="dept"){
            $sql = "SELECT *
                FROM departments
                wHERE username='$username';";
        }
        
        
        $result=mysqli_query($con,$sql);

        if(mysqli_num_rows($result)===1){

            $row=mysqli_fetch_assoc($result);

           // $user_id=$row['id'];
            $user_name=$row['username'];
            $user_password=$row['password'];


            if($username===$user_name){
                if($password===$user_password){
                    //$_SESSION['user_id'] = $user_id;
                    $_SESSION['loginas'] = $loginas;
                    $_SESSION['username'] = $user_name;
                    $_SESSION['password'] = $user_password;
                    if($loginas==="hr"){
                        $_SESSION['admin_id']=$row['admin_id'];
                        }
                        else if($loginas==="sgo"){
                            $_SESSION['sgo_id']=$row['sgo_id'];
                        }
                        else if($loginas==="sa"){
                            $_SESSION['sa_id']=$row['sa_id'];
                        }
                        else if($loginas==="dept"){
                            $_SESSION['dept_id']=$row['dept_id'];
                        }
                    
                    header("Location:../welcome.php");
                }
                else{
          
                   header("Location:index.php?error=Incorrect username or password");
            
                }
            }
            else{
                header("Location:index.php?error=Incorrect username or password");
            }

        }
        else{
            header("Location:index.php?error=Incorrect username or password");
        }
    }
}