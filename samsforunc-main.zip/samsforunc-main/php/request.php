


<html>
    <head></head>


    <body>
        <div class="form-group">

        <form method="POST">
            <label for="">Number of Student Assistant to be Requested:</label>
            <input type="text" name="numberofrequests">
<br>
            <label for="">Preferred Course/s:</label>
            <input type="text" name="preferredcourses" id="">
<br>    
            <label for="">Comment</label>
            <textarea name="comment" id="" cols="30" rows="10"></textarea>
            <button class="btn primary-btn"type="submit" name="submit">Submit</button>
        </form>
        </div>
    </body>
</html>


<?php

include 'conn.php';

session_start();

$dept_id= $_SESSION['dept_id'];

if(isset($_POST['submit'])){

    if(isset($_POST['numberofrequests'])){
        $numberofsa = $_POST['numberofrequests'];
    }
    if(isset($_POST['preferredcourses'])){
        $preferredcourses = $_POST['preferredcourses'];
    }
    if(isset($_POST['comment'])){
        $comment = $_POST['comment'];
    }
    $sql= "INSERT INTO `requests` 
( `dept_id`,`number_of_sa`, `preferred_course`, `comment`) 
VALUES ('$dept_id', '$numberofsa', '$preferredcourses', '$comment');";

$result = mysqli_query($con,$sql);

if(!$result){
    die(mysqli_error($con));
}
else{
    echo "success";
}

}




?>
