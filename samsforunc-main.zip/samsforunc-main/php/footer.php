
<footer id="footer">
<div class="container">
  
  <div class="row">
  <img src="assets/unclogo.png" id="unclogo" width=100px height=100px alt="unc logo">
    <div class="col">
      
      <h6>Information</h6> 

    
          <li>About us</li>
          <li>Documentation</li>

    </div>
    <div class="col order-12">
    <h6>Modules</h6>
    <li>Login</li>
          <li>Apply for SA</li>
    </div>
    <div class="col order-1">
    <h6>Contact</h6> 
    <li>(054) 472 6100</li>
    <li>admission@unc.edu.ph</li>
    <li><a href="https://unc.edu.ph/" style="color:black;">Website</a></li>
    </div>
  </div><hr>
  <br>
  <div class="copyright">
  <p style="text-align:center;">J. Hernandez Avenue 4400 Naga City, Philippines </p> 
<br>      <p style="text-align:center;">Copyright © 2022 SAMSFORUNC</p>
</div>
  

</footer>

