<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
 
   
  <style>

    @media only screen and (max-width: 600px) {
  body {
    background-color: lightblue;
  }
}

    #loginform{
    border: 1px solid;  
   padding : 20px;
    width: 100%;
    position:inherit;
    left: 450px;
        background-color:grey;
    }
    #developers{
      width: 100%;
      height: 500px;
      position: relative;
      top:200px;
      background-color:lightgrey;
      padding:20px;
    }
    #dropdown-input{
        margin-left:50px;
        width: 200;
    }
    #apply{
        position:relative;
        text-align:center;
        top:110px;
    }
    #footer{
        position: static;
        bottom:0;   
        top:500px;
        background-color:grey;
        padding: 30px;
    }
    #background-video {
  width: 100vw;
  height: 100vh;
  object-fit: cover;
  position: fixed;
  left: 0;
  right: 0;
  top: 0;
  bottom: 0;
  z-index: -1;
}
#home{
  width:100%;
  position: relative;
  height:500px;
  top:0;
}
#sams{
  width: 500px;
  height: 250px;
  margin-top: 100px;
 margin-left:35%;
}

#logindiv{
  position: relative;
  top: 100px;
  width:300px;

}

</style></head>
<body>
<?php 
include 'php/header.php';

?>

<video id="background-video" autoplay loop muted poster="assets/unc.png">
<source src="assets/unc.mp4" type="video/mp4">
</video>


<div id="home">
  <img src="assets/redsams2row.png" alt="sams logo" id="sams">
</div>

<div class="form-group" id="logindiv">
<form id="loginform" method="post" action="php/login.php" style="width:500px;height:400px;">
    <legend>Login</legend>
    <label for="dropdown-input">Login As:</label>
  <select id="dropdown-input" name="loginas">
    <option value="hr">Human Resources</option>
    <option value="sgo">SGO</option>
    <option value="dept">Department Head</option>
    <option value="sa">Student Assistant</option>
  </select>
  <div class="form-group" >
    <label for="exampleInputEmail1">Username</label>
    <input type="text" name="username" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter username">
  
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
  </div>
  
  <input type="submit" class="btn btn-primary" name ="submit"value="Submit">
</form>
</div>
<p id="apply">Do you want to <a href="apply.php">Apply</a> as a student assistant?</p>



<div id="developers" >
  <div style="height80px; text-align:center;">
  <h1>The Developers</h1><br>
  </div>
  <div class="row"  style="margin-left:20px">

  <div class="col-1" style="width:200px;margin-left:200px;">
      <img src="assets/boy.jpg" alt="profile picture"
       style="width:200px;height:200px;">
      <h3>Mark Angelo Beluang</h3>
      <p>BSIT <br>markangelobeluang@gmail.com <br>09352773446</p>
    </div>
    <div class="col-2" style="width:200px;margin-left:200px;">
      <img src="assets/boy.jpg" alt="profile picture" style="width:200px;height:200px;">
      <h3>Jude Janculan</h3>
      <p>BSIT <br>janculanjude@gmail.com <br>09485672443</p>
    </div>
    <div class="col-3" style="width:200px;margin-left:100px;">
      <img src="assets/boy.jpg" alt="profile picture" style="width:200px;height:200px;">
      <h3>Jerome Fragata</h3>
      <p>BSIT <br>jerome.fragataf@gmail.com <br>09353376573</p>
    </div>
  </div>

</div>
<div class="footer" style="bottom:0; margin-top:300px; ">
<?php include 'php/footer.php'; ?>

</div>



</body>
</html>