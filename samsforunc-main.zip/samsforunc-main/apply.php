<style>

    ul{
        list-style-type: none;
    }

    aside{
        width: 25%;
    }

    #content{
        margin-top:20px;
        margin-right:30px;
    }
</style>

<?php

include 'php/header.php';

?>




<div class="content-fluid">

<div class="float-lg-right" id="content">
<!--sample-->
<iframe src="under.html"  name="content" id="content" width=900 height=400></iframe>

</div>
<aside>

<ul class="list-group list-group-flush rounded-3" id="menu">
    <li  class="list-group-item d-flex align-items-center transparent p-3"><div class="mb-0">
    <a href="php/procedure.php" target="content" class="link">Procedure</a></div></li>
    <li  class="list-group-item d-flex align-items-center transparent p-3"><div class="mb-0">
        <a href="php/application_form.php" target="content" class="link">Application</a></div></li>
        <li  class="list-group-item d-flex align-items-center transparent p-3"><div class="mb-0">
        <a href="php/requirements.php" target="content" class="link">Requirements</a></div></li>
</ul>
</aside>
</div>

