<?php
session_start();

$loginas= $_SESSION['loginas'];
 $user_name =$_SESSION['username'] ;
 $user_password =$_SESSION['password'] ;
 
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
   
 <style>
 #aside {
  position:relative;
    margin-top:50px;
    top: 0px;
  

   

 
  width: 250px;

  display: block;
    padding: 13px 30px;
    border-bottom: 1px solid #10558d;
    color: rgb(241, 237, 237);
    font-size: 16px;
    

  left: 0;

}
#footer{
        position: static;
        bottom:0;   
        margin-top:150px;
        background-color:grey;
        padding: 30px;
        
}
    
    #unclogo{
  position: relative;
  width: 140px;
  height: 100px;
}
#content{
  border:1px;
  position: relative;
 margin-top:30px;
  margin-right:50px;
}
</style>
 
  </head>
  <body>
  <?php 

  include 'php/header.php';
  $username = $_SESSION['username'];

$loginas = $_SESSION['loginas'];
  
  if($loginas==="hr"){
  include 'php/hr.php';
  }
  else if($loginas==="sgo"){
    include 'php/sgo.php';
  }
  else if($loginas==="sa"){
    include 'php/sa.php';
  }
  else if($loginas==="dept"){
    include 'php/dept.php';
  }
  ?>

            




<!--<aside class="left-sidebar" data-sidebarbg="skin5">

            <div > 
                <nav>
                    <ul id="menu">
                        <li >
                            <a href="">
                                <i ></i>
                                <span >Dashboard</span>
                            </a>
                        </li>
                        <li >
                            <a href="" >
                                <i></i>
                                <span>Profile</span>
                            </a>
                        </li>
                        <li >
                            <a href="" >
                                <i></i>
                                <span>Form Basic</span>
                            </a>
                        </li>
                        <li>
                            <a href="" >
                                <i></i>
                                <span>Table</span>
                            </a>
                        </li>
                        <li >
                            <a href="">
                                <i></i>
                                <span>Icon</span>
                            </a>
                        </li>
                        <li>
                            <a href="" >
                                <i></i>
                                <span >Blank</span>
                            </a>
                        </li>
                        <li>
                            <a href="" >
                                <i></i>
                                <span >404</span>
                            </a>
                        </li>
                    </ul>
                </nav>-->
                <!-- End Sidebar navigation -->
            <!-- </div>-->
            <!-- End Sidebar scroll-->
        <!--</aside> -->
        

        <?php 
        include 'php/footer.php'; ?>
</body>
</html>