<?php 
if (isset($_POST['loginas'])) {
    $selected_option = $_POST['selected_option'];
    echo "Selected option: " . $selected_option;
}


?>